---
description: short one sentence description taken from the invoking prompt, e.g. "i want to create a gitthub workflow for creating and deploying a website prototype based on reference material
author: author name
category: workflow, skill, or tool
type: navigate, educate, or deploy
difficulty: beginner, intermediate, or advanced
references: list of the files passed to the agent, stored in the references path
context: 2-3 sentences or paragraphs on what the user tries to accomplish and how the references relate and should be used
title: generated title of the workflow based on description, e.g. deploy intermediate website prorotype base on reference material
agent: claude.ai, claude desktop, or claude code
model: claude-sonnet-4-5
created_date:
last_modified:
workflow_id: unique id string containg date time author and category
status: not started yet, in progress, finished, initially set to not started yet
tools: "used tools, list only tools that are not obvious to use and yield significant productivity gains, e.g. for deploying with render: render mcp"
skills: used skills or skills to develop, e.g. react page creator skill or corporate identy styling skill or such, dont list the gitthub workflow skill or the skill creator skill which are obvious
steps:
  - list of the enumerated individual step names / descriptions
estimated_time: time estimate for completion
total_steps:
---
